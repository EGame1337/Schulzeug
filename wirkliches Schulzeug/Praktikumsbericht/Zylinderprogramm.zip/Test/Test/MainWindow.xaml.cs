﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Test
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string Radius
        {
            get { return (string)GetValue(RadiusProperty); }
            set { SetValue(RadiusProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Radius.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RadiusProperty =
            DependencyProperty.Register("Radius", typeof(string), typeof(MainWindow), new PropertyMetadata("0"));

        public string Hoehe
        {
            get { return (string)GetValue(HoeheProperty); }
            set { SetValue(HoeheProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Hoehe.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HoeheProperty =
            DependencyProperty.Register("Hoehe", typeof(string), typeof(MainWindow), new PropertyMetadata("0"));




        public Programmdaten Programmdaten
        {
            get { return (Programmdaten)GetValue(ProgrammdatenProperty); }
            set { SetValue(ProgrammdatenProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Programmdaten.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ProgrammdatenProperty =
            DependencyProperty.Register("Programmdaten", typeof(Programmdaten), typeof(MainWindow), new PropertyMetadata(null));


        public MainWindow()
        {
            InitializeComponent();

            Programmdaten = new Programmdaten();
            DataContext = this;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            double.TryParse(Hoehe, out double h);
            double.TryParse(Radius, out double r);

            if (r > 0 && h > 0)
            {
                Programmdaten = new Programmdaten() { Radius = r, Hoehe = h };
            }
        }
    }
}
