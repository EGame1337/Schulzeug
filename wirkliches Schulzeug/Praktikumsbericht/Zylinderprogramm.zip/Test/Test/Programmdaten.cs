﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    public class Programmdaten:INotifyPropertyChanged
    {
        private double m_radius = 0d;
        private double m_hoehe = 0d;

        public double Radius 
        { 
            get => m_radius;
            set
            {
                if (value != m_radius)
                {
                    m_radius = value;
                    OnPropertyChanged("Radius");
                }
            } 
        }
        public double Hoehe 
        { 
            get => m_hoehe; 
            set 
            {
                if ( value != m_hoehe) 
                {
                    m_hoehe = value;
                    OnPropertyChanged("Hoehe");
                }
            } 
        }

        public double Flaecheninhalt_Kreis
        {
            get
            {
                return Radius * Radius * Math.PI;
            }
        }

        public double Kreisumfang
        {
            get
            {
                return 2 * Radius * Math.PI;
            }
        }

        public double Mantelflaeche
        {
            get
            {
                return Kreisumfang * Hoehe;
            }
        }

        public double Zylinderflaeche
        {
            get
            {
                return Flaecheninhalt_Kreis * 2 + Mantelflaeche;
            }
        }        

        public override string ToString()
        {
            return $"G = {Flaecheninhalt_Kreis}{Environment.NewLine}M = {Mantelflaeche}{Environment.NewLine}O = {Zylinderflaeche}";
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public void OnPropertyChanged(string propertyName)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
